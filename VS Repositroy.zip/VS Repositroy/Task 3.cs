using System;

public class WorkItem
{
    private static int currentID;

4 references
protected int ID { get; set; }
5 references
protected string Title { get; set; }
3 references
protected string Description { get; set; }
4 references
protected TimeSpan jobLength { get; set; }
   
    O references
public WorkItem()
    {
        ID = 0;
        Title "Default title";
        Description = "Default description."; jobLength = new TimeSpan();
    }